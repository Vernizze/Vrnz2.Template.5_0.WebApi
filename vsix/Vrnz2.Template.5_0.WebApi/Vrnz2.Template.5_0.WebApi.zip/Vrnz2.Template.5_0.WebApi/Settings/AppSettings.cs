﻿using Vrnz2.BaseContracts.Settings.Base;

namespace $safeprojectname$.Settings
{
    public class AppSettings
        : BaseAppSettings
    {
    }
}
